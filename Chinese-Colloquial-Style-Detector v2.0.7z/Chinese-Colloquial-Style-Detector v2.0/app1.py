from flask import Flask, request, render_template, jsonify
import os
import numpy as np
import pandas as pd
from collections import Counter
import joblib
from sklearn.preprocessing import StandardScaler
from hanlp_restful import HanLPClient
from pyhanlp import HanLP

app = Flask(__name__)
HanLPClient = HanLPClient('https://www.hanlp.com/api', auth='', language='zh')

# 加载模型
models = {
    'log_reg': joblib.load('model/log_reg_model.pkl'),
    'svm': joblib.load('model/svm_model.pkl'),
    'rf': joblib.load('model/rf_model.pkl'),
    'voting': joblib.load('model/voting_clf_model.pkl')
}

# 词性映射标签（删除标点符号和特殊符号）
pos_tag_mapping = {
    'a': 'adjective', 'ad': 'adverbial_adjective', 'ag': 'adjective_morpheme', 'al': 'adjective_phrase',
    'an': 'noun_adjective', 'b': 'distinguishing_word', 'bg': 'distinguishing_morpheme', 'bl': 'distinguishing_phrase',
    'c': 'conjunction', 'cc': 'coordinating_conjunction', 'd': 'adverb', 'dg': 'adverb_dg', 'dl': 'adverbial_phrase',
    'e': 'interjection', 'f': 'direction_word', 'g': 'academic_word', 'gb': 'biological_word', 'gbc': 'biological_category',
    'gc': 'chemical_word', 'gg': 'geographical_word', 'gi': 'computational_word', 'gm': 'mathematical_word', 'gp': 'physical_word',
    'h': 'prefix', 'i': 'idiom', 'j': 'abbreviation', 'k': 'suffix', 'l': 'colloquial_expression', 'm': 'numeral',
    'mg': 'numeral_morpheme', 'Mg': 'special_numeral', 'mq': 'quantity', 'n': 'noun', 'nb': 'biological_name', 'nba': 'animal_name',
    'nbc': 'animal_category', 'nbp': 'plant_name', 'nf': 'food', 'ng': 'noun_morpheme', 'nh': 'medical_word', 'nhd': 'disease',
    'nhm': 'medicine', 'ni': 'organization_word', 'nic': 'sub_organization', 'nis': 'organization_suffix', 'nit': 'educational_institution',
    'nl': 'colloquial_noun', 'nm': 'product_name', 'nmc': 'chemical_name', 'nn': 'job_related_noun', 'nnd': 'profession',
    'nnt': 'position', 'nr': 'personal_name', 'nr1': 'compound_surname', 'nr2': 'mongolian_name', 'nrf': 'transcribed_name',
    'nrj': 'japanese_name', 'ns': 'geographic_name', 'nsf': 'transcribed_geographic_name', 'nt': 'organization_name',
    'ntc': 'company_name', 'ntcb': 'bank', 'ntcf': 'factory', 'ntch': 'hotel', 'nth': 'hospital', 'nto': 'government_institution',
    'nts': 'primary_school', 'ntu': 'university', 'nx': 'alphabet_word', 'nz': 'other_proper_noun', 'o': 'onomatopoeia',
    'p': 'preposition', 'pba': 'preposition_ba', 'pbei': 'preposition_bei', 'q': 'classifier', 'qg': 'classifier_morpheme',
    'qt': 'temporal_classifier', 'qv': 'verbal_classifier', 'r': 'pronoun', 'rg': 'pronoun_morpheme', 'Rg': 'classical_pronoun_morpheme',
    'rr': 'personal_pronoun', 'ry': 'interrogative_pronoun', 'rys': 'locative_interrogative_pronoun', 'ryt': 'temporal_interrogative_pronoun',
    'ryv': 'verbal_interrogative_pronoun', 'rz': 'demonstrative_pronoun', 'rzs': 'locative_demonstrative_pronoun', 'rzt': 'temporal_demonstrative_pronoun',
    'rzv': 'verbal_demonstrative_pronoun', 's': 'locative_word', 't': 'temporal_word', 'tg': 'temporal_morpheme', 'u': 'auxiliary',
    'ud': 'structural_auxiliary', 'ude1': 'structural_auxiliary_1', 'ude2': 'structural_auxiliary_2', 'ude3': 'structural_auxiliary_3',
    'udeng': 'structural_auxiliary_deng', 'udh': 'structural_auxiliary_dehua', 'ug': 'structural_auxiliary_guo', 'uguo': 'structural_auxiliary_guo',
    'uj': 'structural_auxiliary_j', 'ul': 'structural_auxiliary_l', 'ule': 'completed_aspect_marker', 'ulian': 'structural_auxiliary_lian',
    'uls': 'structural_auxiliary_ls', 'usuo': 'nominalization_auxiliary', 'uv': 'structural_auxiliary_v', 'uyy': 'structural_auxiliary_yy',
    'uz': 'structural_auxiliary_z', 'uzhe': 'continuous_aspect_marker', 'uzhi': 'structural_auxiliary_zhi', 'v': 'verb',
    'vd': 'adverbial_verb', 'vf': 'qualitative_verb', 'vg': 'verbal_morpheme', 'vi': 'intransitive_verb', 'vl': 'verbal_phrase',
    'vn': 'noun_verb', 'vshi': 'verb_to_be', 'vx': 'serial_verb', 'vyou': 'verb_to_have', 'y': 'modal_particle', 'yg': 'modal_particle_morpheme',
    'z': 'status_word', 'zg': 'status_morpheme'
}

# 句法依存标签列表（删除标点符号）
dep_tag_list = [
    'acl', 'advcl:loc', 'advmod', 'advmod:dvp', 'advmod:loc', 'advmod:rcomp', 'amod', 'amod:ordmod', 'appos',
    'aux:asp', 'aux:ba', 'aux:modal', 'aux:prtmod', 'auxpass', 'case', 'cc', 'ccomp', 'compound:nn', 'compound:vc',
    'conj', 'cop', 'csubj', 'dep', 'det', 'discourse', 'dobj', 'erased', 'etc', 'mark', 'mark:clf', 'name', 'neg',
    'nmod', 'nmod:assmod', 'nmod:poss', 'nmod:prep', 'nmod:range', 'nmod:tmod', 'nmod:topic', 'nsubj', 'nsubj:xsubj',
    'nsubjpass', 'nummod', 'parataxis:prnmod', 'root', 'xcomp'
]

def pos_to_english(pos):
    return pos_tag_mapping.get(pos, pos)

def calculate_mdd_for_sentence(sentence):
    dependencies = []
    for line in sentence:
        parts = line.split()
        if len(parts) > 6:
            try:
                word_id = int(parts[0])
                head = int(parts[6])
                if head != 0:  # Exclude the root
                    dependencies.append(abs(head - word_id))
            except ValueError:
                continue
    return np.mean(dependencies) if dependencies else 0

def extract_sentence_features(sentence, text_id):
    pos_count = Counter()
    dep_count = Counter()
    syllable_counts = Counter()
    total_syllables = 0
    modal_particles_and_exclamations = 0
    sentence_length = 0

    sentence_text = ""
    for line in sentence:
        parts = line.split()
        if len(parts) > 6:
            pos = parts[3]
            dep = parts[7].split(':')[0] if ':' in parts[7] else parts[7]  # 去掉前面的数字
            word = parts[1]
            pos_count[pos] += 1
            dep_count[dep] += 1
            syllable_counts[len(word)] += 1
            total_syllables += len(word)
            sentence_length += 1
            sentence_text += word + " "
            if pos in ['y', 'e']:  # 语气词和叹词
                modal_particles_and_exclamations += 1

    # 使用 HanLP 进行分词和词性标注
    tokens = HanLP.segment(sentence_text.strip())
    hanlp_pos_count = Counter([pos_to_english(token.nature.toString()) for token in tokens if pos_to_english(token.nature.toString()) in pos_tag_mapping.values()])

    avg_dep_dist = calculate_mdd_for_sentence(sentence)
    avg_syllable_count = total_syllables / sentence_length if sentence_length else 0

    # 计算各词性占比
    pos_ratios = {f'sentence_{pos}_ratio': count / sentence_length for pos, count in hanlp_pos_count.items()}

    # 计算各依存关系占比
    dep_ratios = {f'sentence_{dep}_ratio': count / sentence_length for dep, count in dep_count.items() if dep in dep_tag_list}

    # 初始化所有可能的词性和依存关系占比为0
    all_pos_ratios = {f'sentence_{pos}_ratio': 0 for pos in pos_tag_mapping.values()}
    all_dep_ratios = {f'sentence_{dep}_ratio': 0 for dep in dep_tag_list}
    all_pos_ratios.update(pos_ratios)
    all_dep_ratios.update(dep_ratios)

    # 计算particle_exclamation_ratio
    particle_exclamation_ratio = all_pos_ratios.get('sentence_modal_particle_ratio', 0) + all_pos_ratios.get('sentence_interjection_ratio', 0)

    features = {
        'text_id': text_id,
        'sentence_average_sentence_length': sentence_length,
        'sentence_average_dependency_distance': avg_dep_dist,
        'sentence_particle_exclamation_ratio': particle_exclamation_ratio,
        'sentence_average_syllable_count': avg_syllable_count,
        **all_pos_ratios,
        **all_dep_ratios
    }
    return features

def process_text(text):
    sentences = text.strip().split('\n\n')
    sentence_features_list = []
    for text_id, sentence_text in enumerate(sentences, 1):
        sentence = [line.strip() for line in sentence_text.split('\n')]
        sentence_features = extract_sentence_features(sentence, text_id)
        sentence_features_list.append(sentence_features)
    return sentence_features_list

def summarize_document_features(sentence_features_list):
    total_sentences = len(sentence_features_list)
    total_words = sum(f['sentence_average_sentence_length'] for f in sentence_features_list)
    short_sentences = sum(1 for f in sentence_features_list if f['sentence_average_sentence_length'] < 10)
    total_particle_exclamations = sum(f['sentence_particle_exclamation_ratio'] * f['sentence_average_sentence_length'] for f in sentence_features_list)
    total_syllables = sum(f['sentence_average_syllable_count'] * f['sentence_average_sentence_length'] for f in sentence_features_list)
    total_dependency_distance = sum(f['sentence_average_dependency_distance'] for f in sentence_features_list)

    average_sentence_length = total_words / total_sentences if total_sentences else 0
    short_sentence_ratio = short_sentences / total_sentences if total_sentences else 0
    particle_exclamation_ratio = total_particle_exclamations / total_words if total_words else 0
    average_syllable_count = total_syllables / total_words if total_words else 0
    average_dependency_distance = total_dependency_distance / total_sentences if total_sentences else 0

    pos_totals = Counter()
    dep_totals = Counter()
    for f in sentence_features_list:
        for key in f:
            if key.startswith('sentence_') and key.endswith('_ratio'):
                if 'dependency' not in key:
                    pos_totals[key.replace('sentence_', 'document_')] += f[key] * f['sentence_average_sentence_length']
                else:
                    dep_totals[key.replace('sentence_', 'document_')] += f[key] * f['sentence_average_sentence_length']

    pos_ratios = {key: pos_totals[key] / total_words if total_words else 0 for key in pos_totals}
    dep_ratios = {key: dep_totals[key] / total_words if total_words else 0 for key in dep_totals}

    document_features = {
        'document_average_sentence_length': average_sentence_length,
        'document_short_sentence_ratio': short_sentence_ratio,
        'document_particle_exclamation_ratio': particle_exclamation_ratio,
        'document_average_syllable_count': average_syllable_count,
        'document_average_dependency_distance': average_dependency_distance,
        **pos_ratios,
        **dep_ratios
    }

    return document_features

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    input_text = request.form['text']
    model_name = request.form['model']

    try:
        # 使用HanLP进行依存分析
        doc = HanLPClient(input_text, tasks='dep')
        conll_output = str(doc.to_conll())

        # 保存conll结果到临时文件
        conll_filename = 'temp.conll'
        with open(conll_filename, 'w', encoding='utf-8') as f:
            f.write(conll_output)

        # 读取并处理conll文件，提取特征
        sentence_features_list = process_text(conll_output)
        document_features = summarize_document_features(sentence_features_list)

        for features in sentence_features_list:
            features.update(document_features)

        # 提取所有可能的字段名
        all_possible_keys = set()
        for features in sentence_features_list:
            all_possible_keys.update(features.keys())
        all_possible_keys = list(all_possible_keys)

        # 确保字段顺序
        ordered_keys = [
            'text_id',
            'sentence_average_sentence_length',
            'sentence_average_dependency_distance',
            'sentence_particle_exclamation_ratio',
            'sentence_average_syllable_count'
        ]

        # 添加所有的sentence_XXX_ratio特征
        ordered_keys.extend(sorted([key for key in all_possible_keys if key.startswith('sentence_') and key.endswith('_ratio')]))

        # 添加document级别的特征
        ordered_keys.extend([
            'document_average_sentence_length',
            'document_short_sentence_ratio',
            'document_particle_exclamation_ratio',
            'document_average_syllable_count',
            'document_average_dependency_distance'
        ])

        # 添加所有的document_XXX_ratio特征
        ordered_keys.extend(sorted([key for key in all_possible_keys if key.startswith('document_') and key.endswith('_ratio')]))

        # 将特征转换为DataFrame
        features_df = pd.DataFrame(sentence_features_list, columns=ordered_keys)

        # 删除 text_id 列，因为它不是特征
        X = features_df.drop(columns=['text_id'])

        # 打印特征的数量和名称以检查是否匹配
        print(f"Extracted features count: {X.shape[1]}")
        print(f"Extracted features names: {list(X.columns)}")

        # 标准化特征
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)

        # 选择模型并进行预测
        model = models[model_name]
        predictions = model.predict(X_scaled)
        probabilities = model.predict_proba(X_scaled)

        # 准备返回的数据
        response = {
            'features': features_df.to_dict(orient='records'),
            'predictions': predictions.tolist(),
            'probabilities': probabilities.tolist()
        }

        return jsonify(response)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
